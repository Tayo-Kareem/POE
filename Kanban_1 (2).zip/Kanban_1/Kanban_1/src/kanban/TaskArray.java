/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanban;
import java.util.Scanner;
/**
 * ST10134563
 * @author Tayo Kareem
 * @version JDK 1.13
 * @since JDK 1.8
 */
public class TaskArray {
    
    int i = 0;
    
    Scanner keyboard = new Scanner(System.in);
    
    public String[] DeveloperDetails(){
    
    String[] DeveloperDetails = new String[11];
        return DeveloperDetails;
    }
    
    public int[] taskDuration(){
    int[] taskDuration = new int[11];
        return taskDuration;
    }
    
    public String[] taskStatus(){
    
    String[] taskStatus = new String[11];
        return taskStatus;
    }
   
    public String[] getTaskName(){
    
    String[] getTaskName = new String[11];
        return getTaskName;
    }
       
    public String[] createTaskID(){
    
    String[] createTaskID = new String[11];
        return createTaskID;
    }
    
    
   

}
           
         
        
         
    
    
   
     
    
        
         
         