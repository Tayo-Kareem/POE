/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanban;

import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class deleteArray {
    TaskArray taskArray = new TaskArray();
    String taskName;
    String[] getTaskName = taskArray.getTaskName();
    
        public static String[]removeArray(String[]getTaskName){
            String[]lessArrays=new String[getTaskName.length-1];
            
            Scanner in = new Scanner(System.in);
            System.out.println("what task do you want to delete: " );
            String taskToDelete = in.nextLine();
            
            int indexLessArray = 0;
            
        for (String taskName1 : getTaskName) {
            if (!taskName1.equalsIgnoreCase(taskToDelete)) {
                lessArrays[indexLessArray] = taskName1;
                indexLessArray++;
            }
        }
            return lessArrays;
            
        
        }
    
    
    
    

}
