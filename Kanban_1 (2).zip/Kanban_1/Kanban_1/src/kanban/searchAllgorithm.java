/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanban;

import java.util.Scanner;

public class searchAllgorithm {
    Scanner sc = new Scanner(System.in);
    TaskArray taskArray = new TaskArray();
    String taskName;
    String[] getTaskName = taskArray.getTaskName();
    String[] DeveloperDetails = taskArray.DeveloperDetails();
    String [] taskStatus = taskArray.taskStatus();
    int n;
    int i;
   public void searchWithDeveloperSetails(String getTaskName[]){
       System.out.println("Enter the Task name");
       String src=sc.nextLine();
       
       for( i = 0; i<n; i++){
           if(getTaskName[i].equals(src)){
               System.out.println(src+"is found and the position is :"+ i+1);
               break;
           }
           
       
       }
       if(i==n){
           System.out.println(src+"not found");
       }
   }
      public void searchWithDeveloperDetails(){
       System.out.println("Enter the details of developer");
       int src=sc.nextInt();
       
       for(int i = 0; i<n; i++){
           if(DeveloperDetails[i].equals(src)){
               System.out.println(src+"is found and the position is :"+ i+1);
               break;
           }
           
       
       }
       if(i==n){
           System.out.println(src+"not found");
       }
      }
      
}
