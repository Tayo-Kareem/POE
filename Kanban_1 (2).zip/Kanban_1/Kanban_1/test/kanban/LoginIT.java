/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package kanban;

import static org.junit.jupiter.api.Assertions.assertEquals;  
import static org.junit.jupiter.api.Assertions.assertFalse;
import org.junit.Test;

 /**
 * @author Tayo Kareem
 * @version JDK 1.13
 * @since JDK 1.8
 */

public class LoginIT {
    
    Login lit = new Login();
    
    public LoginIT() {
    }

    @Test
    public void testCheckUserName() {
        
        System.out.println("checkUserName");
        String UserName  = "kyl_1";
        boolean expectedResult = true;
        boolean result = lit.checkUserName(UserName);
        assertEquals(expectedResult, result);
    
        
        System.out.println("checkUserName");
        String UserName1  = "kyl!!!!!!!";
        boolean expectedResult1 = false;
        boolean result1 = lit.checkUserName(UserName1);
        assertEquals(expectedResult1, result1);
    }

    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String Password = "Ch&&sec@ke99!";
        boolean expectedResult = true;
        boolean result = lit.checkPasswordComplexity(Password);
        assertEquals(expectedResult, result);
    }

    @Test
    public void testReturnLoginStatus() {
    }
    
}
