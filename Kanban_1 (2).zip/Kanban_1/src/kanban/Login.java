/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanban;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Tayo Kareem
 * @version JDK 1.13
 * @since JDK 1.8
 */
public class Login {

    //Declare User as a null
    User user = null;

    /**
     * Check the validity of username.
     *
     * @param username: the username to be checked
     * @return true is username is valid, false is otherwise
     */
    public Boolean checkUserName(String username) {

        /*
             ^                   start of username
             (?=.*[_])           postive lookahead for a underscore
             .                   can be anything
             {1,5}               Length from 1 to 5 character
             $                   Endof username
         */
        final String USERNAME_PATTERN
                = "(?=.*[_]).{1,5}$";
        final Pattern pattern = Pattern.compile(USERNAME_PATTERN);
        Matcher matcher = pattern.matcher(username);
        return matcher.matches();

    }

    /**
     * Check the validity of password.
     *
     * @param password
     * @param username: the password to be checked
     * @return true is password is valid, false is otherwise
     */
    public Boolean checkPasswordComplexity(String password) {
        /**
         * ^
         * (?=.*[0-9]) (?=.*[A-Z]) (?=.*[!@#$&()_-[()]:;*,?/*~$*+=<>]) . (8,) $
         */

        final String PASSWORD_PATTERN
                = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[r"
                + "!@#&()_-[{}]:;*,?/*~$^+=<>]).{8,}$";
        final Pattern pattern = Pattern.compile(PASSWORD_PATTERN);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    /**
     * Register a user with valid credentials to use the EasyKanban system: The
     * user's first name
     *
     * @param lastName: the user's last name
     * @param username: The preferred username to log in with
     * @paramm password: The preferred password to log in with
     * @return a message indicating the success/failure of the registration
     */
    public String registerUser(String firstName, String lastName, String username, String password) {
        //Inialise user registration messages

        final String USERNAME_CAPTURED = "Username successfully captured";
        final String USERNAME_FORMAT_ERROR = "Username is not formatted corectly" + "formatted, please ensure" + "that your username contains" + "an underscore and is no more" + "than 5 characters in length";
        final String PASSWORD_CAPTURED = "Password succesfully captured";
        final String PASSWORD_FORMAT_ERROR = "Password is not correctly " + " formatted, please ensure that the password contains" + "at least 8 characters, a capital letter, a number and" + "a special character";

        //intialise the overall registration message
        String registrationMessage = "";

        //Check if the username is valid
        if (!checkUserName(username)) {
            registrationMessage += USERNAME_FORMAT_ERROR + "\n";
        }
        //Check if the password is valid
        if (!checkPasswordComplexity(password)) {
            registrationMessage += PASSWORD_FORMAT_ERROR + "\n";
        }
        //if the overall registration message is empty, the input is valid
        if (registrationMessage.equals("")) {
            if (user == null) {
                user = new User();
            }

            user.setUserFirstName(firstName.trim());
            user.setUserLastName(lastName.trim());
            user.setUserUsername(username.trim());
            user.setUserPassword(password.trim());
            registrationMessage = USERNAME_CAPTURED + "\n"
                    + PASSWORD_CAPTURED + "\n";
        }

        return registrationMessage;

    }

    /**
     * Verifies the user's credentials before allowing the user to log in
     *
     * @param username:the username to be verified
     * @param password: the password to be verified
     * @return true is username is valid, false is otherwise
     */
    public Boolean loginUSer(String username, String password) {
        Boolean isValidCredentials = false;

//if user object is null, the user is not logged in
        if (user != null) {
            if (username.trim().equals(user.getUserUsername())
                    && password.trim().equals(user.getUserPassword())) {
                isValidCredentials = true;
            }
        }
        return isValidCredentials;
    }

    /**
     * Returns an appropriate message to the user concerning the login status
     *
     * @param username:The username for getting the user's login status
     * @param isLoggedIn: login indicator to determine the correct message
     * @return a Message indicating the user's login
     */
    public String returnLoginStatus(String username, Boolean isLoggedIn) {
        String loginStatusMessage;

        //Check if user is logged in and return the right message
        if (isLoggedIn) {
            loginStatusMessage = "Welcome "
                    + user.getUserFirstName()
                    + " "
                    + user.getUserLastName()
                    + " , it is great to see you again";

        } else {
            loginStatusMessage = "Username or password incorrect," + "please try again";
        }
        return loginStatusMessage;
    }
    
    
    
}
